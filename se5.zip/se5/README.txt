Short Exercises #5
------------------

These are the files for the Short Exercises #5.

- se5.py: You will write your solutions in this file.

- test_se5.py: The automated tests for Short Exercises #5.

- pytest.ini: A configuration file that you can safely ignore.

- README.txt: This file.
